package com.example.smartxportdriver.contstants;

public class MyNode {
    public static String VEHICLE_INFO="VEHICLE_INFO";
    public static String VEHICLE_ADMIN="VEHICLE_ADMIN";

}
